import { useState } from "react";
import "./App.css";

const phrases = [
  "No"
  "Really sure?"
  "Pookie please"
  "Don't do this to me"
  "I'm gonna cry"
  "You're breaking me heart :("
  "But"
  "Babie"
  "Love?"
  "Please"
  "Pretty please"
  "Belinda c'mon babes"
  "I'll give you a kiss"
  "Mwaaah<333"
  "Now say yes I couldnt think of anything else to say babes"
];
function App() {
  const [noCount, setNoCount] = useState(0);
  const [yesPressed , setYesPressed] = useState(false);
  const yesButtonSize = noCount * 20 + 16;

  function hanldeNoClick() {
    setNoCount(noCount + 1);
  }

  function getNoButtonText() {
    return phrases[Math.min(noCount, phrases.length - 1)];
  }

  return (
    <div className="valentine-container">
      {yesPressed ? (
      <>
      <img
        alt="bears kissing"
        src="https://media.tenor.com/gUiu1zyxfzYAAAAi/bear-skissing.gif"
        />
        <div className="text">Yay!!!!</div>
        </>
      ) : (
        <>
        <img
        alt="bear with hearts"
        src="https://gifdb.com/images/high/cute-love-bear-roses-ou7zho5oosxngpz.gif"
        />

        <div>Will you be my valentine?</div>
        <div>
          <button
            className="yes-button"
            style={{ fontSize: yesButtonSize}}
          className="no-button"
          style={{ height: `${yesButtonSize}px` }}
          onClick={() => setYesPressed(true)}
          >
            Yes
          </button>
             className="yesButton"
             style={{ fontSize: yesButtonSize}}
             onClick={() => setYesPressed(true)}
            >
              Yes
              </button>
          <button onClick={hanldeNoClick} className="noButton">
          {getNoButtonText()}
          </button>
        </div>
        </>
      )}
    </div>
  );
}


export default App;
